document.addEventListener('DOMContentLoaded', () => {
    // 1. Mobile Navigation Toggle
    const navToggle = document.querySelector('.nav-toggle');
    const navList = document.querySelector('.nav__list');

    if (navToggle && navList) {
        navToggle.addEventListener('click', () => {
            navList.classList.toggle('active');
            navToggle.classList.toggle('active'); // For hamburger animation
        });

        // Close nav when a link is clicked (for single-page navigation)
        const navLinks = document.querySelectorAll('.nav__link');
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (navList.classList.contains('active')) {
                    navList.classList.remove('active');
                    navToggle.classList.remove('active');
                }
            });
        });
    }

    // 2. Smooth Scroll for Internal Navigation Links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();

            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);

            if (targetElement) {
                const offsetTop = targetElement.getBoundingClientRect().top + window.pageYOffset;
                const headerOffset = document.querySelector('.header').offsetHeight; // Adjust for sticky header

                window.scrollTo({
                    top: offsetTop - headerOffset - 20, // 20px extra padding
                    behavior: 'smooth'
                });
            }
        });
    });

    // 3. Mobile Filtering by Brand
    const filterButtons = document.querySelectorAll('.filter-btn');
    const mobileCards = document.querySelectorAll('.mobile-card');

    if (filterButtons.length > 0 && mobileCards.length > 0) {
        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                // Remove 'active' from all buttons
                filterButtons.forEach(btn => btn.classList.remove('active'));
                // Add 'active' to the clicked button
                button.classList.add('active');

                const brand = button.dataset.brand;

                mobileCards.forEach(card => {
                    const cardBrand = card.dataset.brand;
                    if (brand === 'all' || cardBrand === brand) {
                        card.style.display = 'flex'; // Show card
                    } else {
                        card.style.display = 'none'; // Hide card
                    }
                });
            });
        });
    }

    // Optional: Simple form submission handler for Contact Form
    const contactForm = document.querySelector('.contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            // In a real application, you would send this data to a server.
            // For a static site, we'll just log and provide feedback.
            alert('Thank you for your message! We will get back to you soon.');
            contactForm.reset();
        });
    }
});